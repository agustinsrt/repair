document.addEventListener('DOMContentLoaded', () => {
    // Obtener referencias a los elementos del DOM
    const searchForm = document.getElementById('search-svc-form');
    const searchInput = document.getElementById('search-svc');
    const resultsContainer = document.getElementById('svc-results');
    const updateForm = document.getElementById('update-svc-form');
    const addNewButton = document.getElementById('addNewSVC');
    const newFormContainer = document.getElementById('new-svc-form-container');
    const newForm = document.getElementById('add-svc-form');
    const svcDetailsContainer = document.getElementById('svc-details');

    // Función para buscar SVC
    searchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const query = searchInput.value.trim();

        if (!query) {
            alert("Please enter an SVC Code or Name.");
            return;
        }

        try {
            const response = await fetch(`/svc?query=${encodeURIComponent(query)}`);
            const svcs = await response.json();

            resultsContainer.innerHTML = ""; // Limpiar resultados anteriores
            if (svcs.length === 0) {
                resultsContainer.innerHTML = "<p>No SVC found.</p>";
            } else {
                svcs.forEach(svc => {
                    const svcElement = document.createElement('div');
                    svcElement.classList.add('svc-result');
                    svcElement.innerHTML = `
                        <p><strong>${svc.svc_name}</strong> (${svc.svc_code})</p>
                        <button class="update-button" data-code="${svc.svc_code}">Update</button>
                        <button class="delete-button" data-code="${svc.svc_code}" style="background-color: red; color: white;">Delete</button>
                    `;
                    resultsContainer.appendChild(svcElement);
                });
            }

            // Vincular botones de "Update" y "Delete"
            document.querySelectorAll('.update-button').forEach(button => {
                button.addEventListener('click', () => loadSVCDetails(button.dataset.code));
            });

            document.querySelectorAll('.delete-button').forEach(button => {
                button.addEventListener('click', () => deleteSVC(button.dataset.code));
            });
        } catch (error) {
            console.error("Error fetching SVCs:", error);
            alert("An error occurred while searching for SVC.");
        }
    });

    // Función para cargar detalles de un SVC en el formulario de edición
    const loadSVCDetails = async (svcCode) => {
        try {
            const response = await fetch(`/svc/${encodeURIComponent(svcCode)}`);
            if (response.ok) {
                const svc = await response.json();
    
                // Llena los campos del formulario con los detalles del SVC
                document.getElementById('svc-code').value = svc.svc_code;
                document.getElementById('svc-name').value = svc.svc_name;
                document.getElementById('preauth-amount').value = svc.preauthorization_amount;
                document.getElementById('diagnostic-fee').value = svc.diagnostic_fee;
                document.getElementById('labor-cost').value = svc.labor;
                document.getElementById('sealed-system-labor').value = svc.major_sealed_system_labor;
                document.getElementById('shipping-address').value = svc.shipping_address;
    
                // Muestra el formulario para editar los detalles
                document.getElementById('svc-details').style.display = 'block';
            } else {
                alert("An error occurred while loading the SVC details.");
            }
        } catch (error) {
            console.error("Error loading SVC details:", error);
            alert("An error occurred while loading the SVC details.");
        }
    };
    // Función para actualizar un SVC
    updateForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(updateForm);

        try {
            await fetch(`/svc/${encodeURIComponent(formData.get('svc_code'))}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData))
            });

            alert("SVC updated successfully.");
            svcDetailsContainer.style.display = "none"; // Ocultar el formulario de edición
        } catch (error) {
            console.error("Error updating SVC:", error);
            alert("An error occurred while updating the SVC.");
        }
    });

    // Función para eliminar un SVC
    const deleteSVC = async (svcCode) => {
        try {
            const response = await fetch(`/svc/${encodeURIComponent(svcCode)}`, { method: 'DELETE' });

            if (response.ok) {
                alert("SVC deleted successfully.");
                resultsContainer.innerHTML = ""; // Limpiar resultados
            } else {
                alert("Failed to delete SVC.");
            }
        } catch (error) {
            console.error("Error deleting SVC:", error);
            alert("An error occurred while deleting the SVC.");
        }
    };

    // Función para mostrar el formulario de nuevo SVC
    addNewButton.addEventListener('click', () => {
        svcDetailsContainer.style.display = "none"; // Ocultar detalles de SVC
        newFormContainer.style.display = "block"; // Mostrar formulario de nuevo SVC
    });

    // Función para guardar un nuevo SVC
    newForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(newForm);

        try {
            await fetch(`/svc`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(formData))
            });

            alert("SVC added successfully.");
            newFormContainer.style.display = "none"; // Ocultar formulario de nuevo SVC
            newForm.reset(); // Limpiar campos
        } catch (error) {
            console.error("Error adding new SVC:", error);
            alert("An error occurred while adding the SVC.");
        }
    });
});